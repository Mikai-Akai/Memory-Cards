/*
 * Programación Interactiva
 * Equipo de trabajo:
 * -Andres Pineda Cortez 1843660-3743
 * -Mateo Obando
 * Taller # 1 -Juego Memory Cards
 */
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class Control.
 */
public class Control {
	
	/** The contador. */
	private int contador = 0;
	
	/** The posiciones. */
	private int[] posiciones = new int[20];
	
	/**
	 * Instantiates a new control.
	 */
	Control() {
		for(int i= 0;i<20;i++) {
				Random aleatorio = new Random();
				int NumTarjeta = aleatorio.nextInt(10+1);
				for(int j = 0;j<20;j++) {
					if (posiciones[j] == NumTarjeta && contador < 2) {
						contador++;
						posiciones[j] = NumTarjeta;
					}
				}
		}
	}
}
